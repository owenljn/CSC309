</div>
<div id="footer"></div>
<div id="footerbox">
<div class="footer">Connect4 is proudly powered by <a target="_blank">Owen Lu(g2lujinn)</a> <br />
Content copyright &copy;  2014-2015. All rights reserved. </div>