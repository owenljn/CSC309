<?php

class Account extends CI_Controller {
     
    function __construct() {
        parent::__construct();
        session_start();
    }

    public function _remap($method, $params = array()) {

        $protected = array('updatePasswordForm','updatePassword','index','logout');

        if (in_array($method,$protected) && !isset($_SESSION['user']))
            redirect('account/loginForm', 'refresh'); 

        return call_user_func_array(array($this, $method), $params);
    }


    function loginForm() {
        $data["title"] = "Log In - Connect4";
        $data["main"] = "account/loginForm";
        
        $this->load->view("template", $data);
    }

    function login() {
        $data["title"] = "Log In - Connect4";
        $data["main"] = "account/loginForm";
        
        $this->load->library('form_validation');
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');

        if ($this->form_validation->run() == FALSE)
        {
            $this->load->view('account/loginForm');
        }
        else
        {
            $login = $this->input->post('username');
            $clearPassword = $this->input->post('password');

            $this->load->model('user_model');

            $user = $this->user_model->get($login);

            if (isset($user) && $user->comparePassword($clearPassword)) {
                $_SESSION['user'] = $user;
                $data['user']=$user;

                $this->user_model->updateStatus($user->id, User::AVAILABLE);

                redirect('arcade/index', 'refresh'); //redirect to the main application page
            }
            else {
                $data['errorMsg']='Incorrect username or password!';
                $this->load->view('template',$data);
            }
        }
    }

    function logout() {
        $user = $_SESSION['user'];
        $this->load->model('user_model');
        $this->user_model->updateStatus($user->id, User::OFFLINE);
        session_destroy();
        redirect('account/index', 'refresh'); //Then we redirect to the index page again
    }
    
    function captchaImage() {
        $this->load->library("securimage");
        $this->securimage->show();
    }

    function newForm() {
        $data["main"] = "account/newForm";
        $data["title"] = "Register - Connect4";
        $data["script"] = "account/_js";
        $data["data"] = $data;
        
        $this->load->view("template", $data);
    }
    
    function _verifySecurimage($input) {
        $this->load->library("securimage");
        return $this->securimage->check($input);
    }

    function createNew() {
        
        $this->load->library('form_validation');
        $this->load->library("securimage");
        $this->form_validation->set_rules('username', 'Username', 'required|is_unique[user.login]');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('first', 'First', "required");
        $this->form_validation->set_rules('last', 'last', "required");
        $this->form_validation->set_rules('email', 'Email', "required|is_unique[user.email]");
        $this->form_validation->set_rules("imagecode", "Captcha", "required|callback__verifySecurimage");
        $this->form_validation->set_message('_verifySecurimage', 'Incorrect value for %s. Please try again.');

         
        if ($this->form_validation->run() == FALSE)
        {
            $data["main"] = "account/newForm";
            $data["title"] = "Register - Connect4";
            $data["script"] = "account/_js";
            $data["data"] = $data;
            
            $this->load->view("template", $data);
        }
        else
        {
            $data["main"] = "account/loginForm";
            $data["title"] = "Log In - Connect4";
            
            $user = new User();

            $user->login = $this->input->post('username');
            $user->first = $this->input->post('first');
            $user->last = $this->input->post('last');
            $clearPassword = $this->input->post('password');
            $user->encryptPassword($clearPassword);
            $user->email = $this->input->post('email');
             
            $this->load->model('user_model');

             
            $error = $this->user_model->insert($user);
             
            $this->load->view('account/loginForm');
        }
    }


    function updatePasswordForm() {
        $data["main"] = "account/updatePasswordForm";
        $data["title"] = "Update Password - Title";
        $data["script"] = "account/_js";
        $data["data"] = $data;
        
        $this->load->view("template", $data);
    }

    function updatePassword() {
        $data["main"] = "account/updatePasswordForm";
        $data["title"] = "Update Password - Title";
        $data["script"] = "account/_js";
        $data["data"] = $data;
        
        $this->load->library('form_validation');
        $this->form_validation->set_rules('oldPassword', 'Old Password', 'required');
        $this->form_validation->set_rules('newPassword', 'New Password', 'required');
         
         
        if ($this->form_validation->run() == FALSE)
        {            
            $this->load->view("template", $data);
        }
        else
        {
            $user = $_SESSION['user'];
             
            $oldPassword = $this->input->post('oldPassword');
            $newPassword = $this->input->post('newPassword');

            if ($user->comparePassword($oldPassword)) {
                $user->encryptPassword($newPassword);
                $this->load->model('user_model');
                $this->user_model->updatePassword($user);
                redirect('arcade/index', 'refresh'); //Then we redirect to the index page again
            }
            else {
                $data['errorMsg']="Incorrect password!";
                $this->load->view("template", $data);
            }
        }
    }

    function recoverPasswordForm() {
        $this->load->view('account/recoverPasswordForm');
    }

    function recoverPassword() {
        $this->load->library('form_validation');
        $this->form_validation->set_rules('email', 'email', 'required');

        if ($this->form_validation->run() == FALSE)
        {
            $this->load->view('account/recoverPasswordForm');
        }
        else
        {
            $email = $this->input->post('email');
            $this->load->model('user_model');
            $user = $this->user_model->getFromEmail($email);

            if (isset($user)) {
                $newPassword = $user->initPassword();
                $this->user_model->updatePassword($user);

                $this->load->library('email');
                 
                $config['protocol']    = 'smtp';
                $config['smtp_host']    = 'ssl://smtp.gmail.com';
                $config['smtp_port']    = 465;
                $config['smtp_timeout'] = '7';
                $config['smtp_user']    = 'CSC309A4connect4@gmail.com';
                $config['smtp_pass']    = 'CSC309A4';
                $config['charset']    = 'iso-8859-1';
                $config['newline']    = "\r\n";
                $config['mailtype'] = 'html';
                $config['validation'] = TRUE; 

                $this->email->initialize($config);

                $this->email->from('csc309A4connect4@gmail.com', 'Admin');
                $this->email->to($user->email);

                $this->email->subject('Password recovery');
                $this->email->message("Your new password is $newPassword");

                $result = $this->email->send();
                $this->load->view('account/emailPage');

            }
            else {
                $data['errorMsg']="Sorry this email doesn't exist in our database.";
                $this->load->view('account/recoverPasswordForm',$data);
            }
        }
    }
}

